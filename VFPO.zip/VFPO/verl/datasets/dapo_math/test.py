import pandas as pd

# 读取 Parquet 文件
parquet_file_path = 'aime-2024.parquet'
df = pd.read_parquet(parquet_file_path)

# 将数据保存为 JSON 文件
json_file_path = 'aime-2024.json'
df.to_json(json_file_path, orient='records', lines=True)

parquet_file_path = 'dapo-math-17k.parquet'
df = pd.read_parquet(parquet_file_path)

# 将数据保存为 JSON 文件
json_file_path = 'dapo-math-17k.json'
df.to_json(json_file_path, orient='records', lines=True)


#去掉重复的
# import json

# # 原 JSON 文件路径
# input_json_file_path = 'aime-2024.json'
# # 新的 JSON 文件路径
# output_json_file_path = 'aime-2024_unique.json'

# # 读取原 JSON 文件内容
# with open(input_json_file_path, 'r', encoding='utf-8') as f:
#     lines = f.readlines()

# # 用于存储唯一行的集合
# unique_lines = set()
# # 存储处理后的行
# filtered_lines = []

# # 遍历每一行
# for line in lines:
#     try:
#         # 解析 JSON 行
#         data = json.loads(line)
#         # 将解析后的 JSON 转换为字符串
#         line_str = json.dumps(data, sort_keys=True)
#         if line_str not in unique_lines:
#             # 如果该行不在唯一行集合中，则添加到集合和处理后的行列表中
#             unique_lines.add(line_str)
#             filtered_lines.append(line)
#     except json.JSONDecodeError:
#         # 处理 JSON 解析错误
#         print(f"Error decoding line: {line}")

# # 将处理后的行保存到新的 JSON 文件
# with open(output_json_file_path, 'w', encoding='utf-8') as f:
#     f.writelines(filtered_lines)