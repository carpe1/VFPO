# Copyright 2024 Bytedance Ltd. and/or its affiliates
# Copyright 2022 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Core functions to implement PPO algorithms.
The function implemented in this file should be used by trainer with different distributed strategies to
implement PPO
"""

import numpy as np
import torch
from collections import defaultdict

import verl.utils.torch_functional as verl_F


class AdaptiveKLController:
    """
    Adaptive KL controller described in the paper:
    https://arxiv.org/pdf/1909.08593.pdf
    """

    def __init__(self, init_kl_coef, target_kl, horizon):
        self.value = init_kl_coef
        self.target = target_kl
        self.horizon = horizon

    def update(self, current_kl, n_steps):
        target = self.target
        proportional_error = np.clip(current_kl / target - 1, -0.2, 0.2)
        mult = 1 + proportional_error * n_steps / self.horizon
        self.value *= mult


class FixedKLController:
    """Fixed KL controller."""

    def __init__(self, kl_coef):
        self.value = kl_coef

    def update(self, current_kl, n_steps):
        pass


def get_kl_controller(config):
    if config.critic.kl_ctrl.type == 'fixed':
        kl_ctrl = FixedKLController(kl_coef=config.critic.kl_ctrl.kl_coef)
    elif config.critic.kl_ctrl.type == 'adaptive':
        assert config.kl_ctrl.horizon > 0, f'horizon must be larger than 0. Got {config.critic.kl_ctrl.horizon}'
        kl_ctrl = AdaptiveKLController(init_kl_coef=config.critic.kl_ctrl.kl_coef,
                                       target_kl=config.critic.kl_ctrl.target_kl,
                                       horizon=config.critic.kl_ctrl.horizon)
    else:
        raise ValueError('Unknown kl_ctrl type')

    return kl_ctrl


def compute_gae_advantage_return(token_level_rewards: torch.Tensor, values: torch.Tensor, eos_mask: torch.Tensor,
                                 gamma: torch.Tensor, lam: torch.Tensor):
    """Adapted from https://github.com/huggingface/trl/blob/main/trl/trainer/ppo_trainer.py

    Args:
        token_level_rewards: `(torch.Tensor)`
            shape: (bs, response_length)
        values: `(torch.Tensor)`
            shape: (bs, response_length)
        eos_mask: `(torch.Tensor)`
            shape: (bs, response_length). [EOS] mask. The token after [EOS] have mask zero.
        gamma: `(float)`
            discounted factor used in RL
        lam: `(float)`
            lambda value when computing Generalized Advantage Estimation (https://arxiv.org/abs/1506.02438)

    Returns:
        advantages: `(torch.Tensor)`
            shape: (bs, response_length)
        Returns: `(torch.Tensor)`
            shape: (bs, response_length)

    """
    with torch.no_grad():
        lastgaelam = 0
        advantages_reversed = []
        gen_len = token_level_rewards.shape[-1]

        for t in reversed(range(gen_len)):
            nextvalues = values[:, t + 1] if t < gen_len - 1 else 0.0
            delta = token_level_rewards[:, t] + gamma * nextvalues - values[:, t]
            lastgaelam = delta + gamma * lam * lastgaelam
            advantages_reversed.append(lastgaelam)
        advantages = torch.stack(advantages_reversed[::-1], dim=1)

        returns = advantages + values
        advantages = verl_F.masked_whiten(advantages, eos_mask)
    return advantages, returns



#我新加的
def compute_entropy_rewards(log_probs, completion_mask, index, rewards1, high_ent_mask=None):
    """
    直接利用index完成计算，支持任意组样本数，输出与输入顺序对齐
    仅返回全局统计标量，新增打印验证对齐性
    
    输入：
        log_probs: (bs, seq_len) → 逐token对数概率
        completion_mask: (bs, seq_len) → 有效token掩码
        index: (bs,) → 每个样本的组索引（Tensor，已转为整数）
    输出：
        rewards2: (bs,) → 与输入顺序对齐的熵奖励
        sample_group_var: (bs,) → 与输入顺序对齐的组方差
        global_group_mean_avg: float → 所有组的均值的均值（全局平均）
        global_group_var_avg: float → 所有组的方差的均值（全局平均）
    """
    with torch.no_grad():
        # ========== 关键修改：合并高熵掩码与有效掩码 ==========
        # 有效掩码 = 原始有效Token（completion_mask） + 高熵Token（high_ent_mask）
        if high_ent_mask is not None:
            # 校验掩码维度一致性
            assert high_ent_mask.shape == completion_mask.shape, \
                f"高熵掩码形状{high_ent_mask.shape}需与有效掩码形状{completion_mask.shape}一致"
            # 合并掩码：仅保留「高熵+有效」的Token
            effective_mask = completion_mask & high_ent_mask
            print(f"\n[ENTROPY REWARDS] 使用高熵掩码high_ent_mask_high过滤Token | 高熵Token占比：{(effective_mask.sum() / completion_mask.sum()).item():.4f}")
        else:
            # 兜底：无高熵掩码时使用原始有效掩码
            effective_mask = completion_mask
        # =====================================================

        # 1. 计算每个样本的平均概率 pi（仅基于高熵+有效Token）
        # 高熵Token的序列长度（替代原seq_lengths）
        seq_lengths = effective_mask.sum(dim=1).clamp(min=1)  # 避免除以0
        # 高熵Token的累计log_prob（替代原seq_log_probs）
        seq_log_probs = (log_probs * effective_mask).sum(dim=1)
        avg_log_probs = seq_log_probs / seq_lengths  # 高熵Token的平均log_prob
        pi = torch.exp(avg_log_probs)  # (bs,) → 仅基于高熵Token的平均概率
        bs = pi.shape[0]

        # 2. 基于index动态分组，计算每组统计量 + 打印分组信息
        unique_groups = torch.unique(index)  # 所有唯一组ID
        group_num = len(unique_groups)
        group_mean_list = []  # 存储每组的均值（用于计算全局平均）
        group_var_list = []   # 存储每组的方差（用于计算全局平均）
        group_pos_mean_list = []      # 新增：组内rewards1>0的pi均值
        group_neg_mean_list = []      # 新增：组内rewards1<0的pi均值

        print(f"\n[ENTROPY REWARDS] 开始分组计算，共{group_num}个组，总样本数{bs}")
        for group_id in unique_groups:
            group_id_int = group_id.item()
            # 筛选当前组的样本索引和概率
            group_mask = (index == group_id)
            # group_sample_indices = torch.where(group_mask)[0].tolist()  # 当前组的样本索引（输入顺序）
            group_pi = pi[group_mask]  # 当前组的概率
            group_rewards1 = rewards1[group_mask]  # 新增：获取该组的rewards1
            group_size = len(group_pi)

            # 计算组内均值和方差
            group_mean = group_pi.mean().item()
            group_var = group_pi.var(unbiased=True).item()  # 无偏方差

            # # ========== 核心修改：拆分正负样本计算均值 ==========
            # # 筛选组内rewards1>0/<0的样本pi
            # pos_mask = group_rewards1 > 0
            # neg_mask = group_rewards1 < 0
            # # 计算正负均值（无对应样本时用组整体均值兜底）
            # group_pos_mean = group_pi[pos_mask].mean().item() if pos_mask.any() else group_mean
            # group_neg_mean = group_pi[neg_mask].mean().item() if neg_mask.any() else group_mean
            # # =====================================================

            # 存储数据用于后续全局计算和打印
            group_mean_list.append(group_mean)
            group_var_list.append(group_var)
            # group_pos_mean_list.append(group_pos_mean)
            # group_neg_mean_list.append(group_neg_mean)

            # # 打印每组详细信息（验证组与样本的对应关系）
            # print(f"[ENTROPY REWARDS] 组ID: {group_id_int} | 样本索引（输入顺序）: {group_sample_indices} | "
            #       f"组内样本数: {group_size} | 组均值: {group_mean:.4f} | 组方差: {group_var:.6f}")
            # 打印增强：新增正负均值信息
            # print(f"[ENTROPY REWARDS] 组ID: {group_id_int} | 样本索引: {group_sample_indices} | "
            #       f"组内样本数: {group_size} | 正样本数: {pos_mask.sum().item()} | 负样本数: {neg_mask.sum().item()} | "
            #       f"组均值: {group_mean:.4f} | 正均值: {group_pos_mean:.4f} | 负均值: {group_neg_mean:.4f} | "
            #       f"组方差: {group_var:.6f}")

        # 3. 计算全局统计量（所有组的均值的均值、所有组的方差的均值）
        global_group_mean_avg = np.mean(group_mean_list)
        global_group_var_avg = np.mean(group_var_list)
        # print(f"[ENTROPY REWARDS] 全局统计 - 所有组的均值的均值: {global_group_mean_avg:.4f} | "
        #       f"所有组的方差的均值: {global_group_var_avg:.6f}")

        return (
            global_group_mean_avg,   # 标量 → 所有组的均值的均值
            global_group_var_avg,     # 标量 → 所有组的方差的均值
        )

# NOTE(sgm): this implementation only consider outcome supervision, where the reward is a scalar.
def compute_grpo_outcome_advantage(token_level_rewards: torch.Tensor,
                                 eos_mask: torch.Tensor,
                                 index: torch.Tensor,
                                 log_probs: torch.Tensor,  # 新增：生成概率参数
                                 high_ent_mask_low: torch.Tensor = None,  # ========== 新增：高熵Token掩码 ==========
                                 high_ent_mask_high: torch.Tensor = None,  # ========== 新增：高熵Token掩码 ==========
                                 d: float = 1.0,  # 保持默认值
                                 c: float = 1.0,  # 保持默认值
                                 epsilon: float = 1e-6,
                                more_start_step_flag:float =0):
    """
    Compute advantage for GRPO with entropy rewards from generation probabilities.
    保持d和c的默认值，修复设备和分组逻辑问题
    """
    response_length = token_level_rewards.shape[-1]
    scores = token_level_rewards.sum(dim=-1)

    id2score = defaultdict(list)
    id2mean = {}
    id2std = {}

    with torch.no_grad():
        bsz = scores.shape[0]
        for i in range(bsz):
            id2score[index[i]].append(scores[i])
        for idx in id2score:
            if len(id2score[idx]) == 1:
                id2mean[idx] = torch.tensor(0.0)
                id2std[idx] = torch.tensor(1.0)
            elif len(id2score[idx]) > 1:
                id2mean[idx] = torch.mean(torch.tensor(id2score[idx]))
                id2std[idx] = torch.std(torch.tensor([id2score[idx]]))
            else:
                raise ValueError(f"no score in prompt index: {idx}")
        for i in range(bsz):
            scores[i] = (scores[i] - id2mean[index[i]]) / (id2std[index[i]] + epsilon)
        scores = scores.unsqueeze(-1).tile([1, response_length]) * eos_mask


    response_length = token_level_rewards.shape[-1]
    device = token_level_rewards.device  # 统一设备
    bs = token_level_rewards.shape[0]

    # 输出原始index的部分内容（前10个元素）
    print(f"[GRPO FIX] 原始index类型：{type(index)}，总长度：{len(index)}")
    print(f"[GRPO FIX] 原始index前10个元素：{index[:32]}")  # 仅输出前10个，避免冗余
    # ====================== 关键修复开始 ======================
    # 修复1：处理index参数的类型错误（numpy数组→PyTorch张量）
    # 错误原因：torch.unique要求输入为Tensor，但接收到了numpy.ndarray
    if not isinstance(index, torch.Tensor):
        # 检查是否为object类型（字符串数组）
        if index.dtype == np.object_:
            print(f"[GRPO FIX] Detected string index, converting to numerical indices")
            # 1. 唯一化字符串并映射到整数
            unique_strs, inverse_indices = np.unique(index, return_inverse=True)
            str_to_id = {s: i for i, s in enumerate(unique_strs)}
            index = np.array([str_to_id[s] for s in index], dtype=np.int64)
        # 转换为张量
        index = torch.from_numpy(index)
    
                                                # # 原始index（字符串）
                                                # ['prompt0', 'prompt0', 'prompt1', 'prompt1']
                                                # # 映射后index（数值）
                                                # [0, 0, 1, 1]
    # # 输出转化后index的部分内容（前10个元素）
    # print(f"[GRPO FIX] 转化后index类型：{type(index)}，设备：{index.device}")
    # print(f"[GRPO FIX] 转化后index前10个元素：{index[:32]}")  # 仅输出前10个
    # 修复2：确保所有张量在同一设备（解决分布式训练中的设备不匹配问题）
    # 错误原因：不同张量可能分布在不同设备（如CPU/GPU）导致计算失败
    index = index.to(device)
    eos_mask = eos_mask.to(device)
    log_probs = log_probs.to(device)
    print(f"[GRPO FIX] Moved all tensors to device: {device}")
    # ====================== 关键修复结束 ======================
    
    # 1. 计算原始奖励 (rewards1)
    rewards1 = token_level_rewards.sum(dim=-1)  # (bs,)
    # print(f"\n[DEBUG] rewards1 取值验证：")
    # print(f"  形状：{rewards1.shape}")
    # print(f"  唯一值：{torch.unique(rewards1).cpu().numpy()}")  # 核心验证：是否只有1和-1
    # print(f"  前10个样本值：{rewards1[:32].cpu().numpy()}")
    # print(f"  统计信息 - 均值：{rewards1.mean().item():.4f} | 最大值：{rewards1.max().item()} | 最小值：{rewards1.min().item()}")
    # print(f"  正样本数（=1）：{(rewards1 == 1).sum().item()} | 负样本数（=-1）：{(rewards1 == -1).sum().item()} | 其他值样本数：{((rewards1 != 1) & (rewards1 != -1)).sum().item()}")
    # 2. 计算每个prompt的生成数量（num_generations）
    unique_indices, counts = torch.unique(index, return_counts=True)
    print(f"[DEBUG] 所有组的总样本数：{counts.tolist()}")  # 新增打印
    num_generations = counts[0].item()  # 假设所有分组数量相同
    if not torch.all(counts == counts[0]):
        raise ValueError(f"所有分组必须有相同数量的样本，实际为 {counts.tolist()}")
    # if bs % num_generations != 0:
    #     raise ValueError(f"总样本数{bs}不能被每组样本数{num_generations}整除，请确保组内样本数一致！")
    # # 2. 核心判断：reshape后每行元素是否全相同（即同组连续）
    # if not (index.reshape(-1, num_generations) == index.reshape(-1, num_generations)[:, 0:1]).all():
    #     raise ValueError(
    #         f"[VALIDATION FAILED] 样本排列与index不匹配！\n"
    #         f"存在组样本未连续排列的情况，请确保同组样本连续排列（如num_generations=2时，index应为[0,0,1,1]）。"
    #     )
    # print(f"[DATA VALIDATION PASSED] 样本排列与index匹配！")
    
    # 3. 计算熵奖励 (rewards2) → ========== 关键修改：传递high_ent_mask ==========
    group_pi_mean, group_pi_var= compute_entropy_rewards(
        log_probs=log_probs,
        completion_mask=eos_mask,  # 原始有效掩码
        index=index,
        rewards1=rewards1,  # 新增传入rewards1
        high_ent_mask=high_ent_mask_high  # 传递高熵掩码
    )

    return (
        scores, 
        scores, 
        group_pi_mean,  # 分组均值的均值（监控用）
        group_pi_var  # 分组方差的均值（监控用）
    )


# def compute_grpo_outcome_advantage(token_level_rewards: torch.Tensor,
#                                    eos_mask: torch.Tensor,
#                                    index: torch.Tensor,
#                                    epsilon: float = 1e-6):
#     """
#     Compute advantage for GRPO, operating only on Outcome reward 
#     (with only one scalar reward for each response).
#     Args:
#         token_level_rewards: `(torch.Tensor)`
#             shape: (bs, response_length)
#         eos_mask: `(torch.Tensor)`
#             shape: (bs, response_length)
    
#     Returns:
#         advantages: `(torch.Tensor)`
#             shape: (bs, response_length)
#         Returns: `(torch.Tensor)`
#             shape: (bs, response_length)
#     """
#     response_length = token_level_rewards.shape[-1]
#     scores = token_level_rewards.sum(dim=-1)

#     id2score = defaultdict(list)
#     id2mean = {}
#     id2std = {}

#     with torch.no_grad():
#         bsz = scores.shape[0]
#         for i in range(bsz):
#             id2score[index[i]].append(scores[i])
#         for idx in id2score:
#             if len(id2score[idx]) == 1:
#                 id2mean[idx] = torch.tensor(0.0)
#                 id2std[idx] = torch.tensor(1.0)
#             elif len(id2score[idx]) > 1:
#                 id2mean[idx] = torch.mean(torch.tensor(id2score[idx]))
#                 id2std[idx] = torch.std(torch.tensor([id2score[idx]]))
#             else:
#                 raise ValueError(f"no score in prompt index: {idx}")
#         for i in range(bsz):
#             scores[i] = (scores[i] - id2mean[index[i]]) / (id2std[index[i]] + epsilon)
#         scores = scores.unsqueeze(-1).tile([1, response_length]) * eos_mask

#     return scores, scores

def compute_rloo_outcome_advantage(token_level_rewards: torch.Tensor,
                                   eos_mask: torch.Tensor,
                                   index: torch.Tensor,
                                   epsilon: float = 1e-6):
    """
    Compute advantage for RLOO based on https://arxiv.org/abs/2402.14740
    Args:
        token_level_rewards: `(torch.Tensor)`
            shape: (bs, response_length)
        eos_mask: `(torch.Tensor)`
            shape: (bs, response_length)

    Returns:
        advantages: `(torch.Tensor)`
            shape: (bs, response_length)
        Returns: `(torch.Tensor)`
            shape: (bs, response_length)
    """
    response_length = token_level_rewards.shape[-1]
    scores = token_level_rewards.sum(dim=-1)

    id2score = defaultdict(list)
    id2mean = {}

    with torch.no_grad():
        bsz = scores.shape[0]
        for i in range(bsz):
            id2score[index[i]].append(scores[i])
        for idx in id2score:
            if len(id2score[idx]) == 1:
                id2mean[idx] = torch.tensor(0.0)
            elif len(id2score[idx]) > 1:
                id2mean[idx] = torch.mean(torch.tensor(id2score[idx]))
            else:
                raise ValueError(f"no score in prompt index: {idx}")
        for i in range(bsz):
            response_num = len(id2score[index[i]])
            if response_num > 1:
                scores[i] = scores[i] * response_num / (response_num -
                                                        1) - id2mean[index[i]] * response_num / (response_num - 1)
        scores = scores.unsqueeze(-1).tile([1, response_length]) * eos_mask

    return scores, scores


def compute_reinforce_plus_plus_outcome_advantage(token_level_rewards: torch.Tensor, eos_mask: torch.Tensor,
                                                  gamma: torch.Tensor):
    """
    Compute advantage for REINFORCE++. 
    This implementation is based on the paper: https://arxiv.org/abs/2501.03262
    Args:
        token_level_rewards: `(torch.Tensor)`
            shape: (bs, response_length)
        eos_mask: `(torch.Tensor)`
            shape: (bs, response_length)
    
    Returns:
        advantages: `(torch.Tensor)`
            shape: (bs, response_length)
        Returns: `(torch.Tensor)`
            shape: (bs, response_length)
    """

    with torch.no_grad():
        returns = torch.zeros_like(token_level_rewards)
        running_return = 0

        for t in reversed(range(token_level_rewards.shape[1])):
            running_return = token_level_rewards[:, t] + gamma * running_return
            returns[:, t] = running_return
            # Reset after EOS
            running_return = running_return * eos_mask[:, t]

        advantages = verl_F.masked_whiten(returns, eos_mask)
        advantages = advantages * eos_mask

    return advantages, returns


def compute_remax_outcome_advantage(token_level_rewards: torch.Tensor, reward_baselines: torch.Tensor,
                                    eos_mask: torch.Tensor):
    """
    Compute advantage for ReMax, operating only on Outcome reward 
    This implementation is based on the paper: https://arxiv.org/abs/2310.10505

    (with only one scalar reward for each response).
    Args:
        token_level_rewards: `(torch.Tensor)`
            shape: (bs, response_length)
        reward_baselines: `(torch.Tensor)`
            shape: (bs,)
        eos_mask: `(torch.Tensor)`
            shape: (bs, response_length)
    
    Returns:
        advantages: `(torch.Tensor)`
            shape: (bs, response_length)
        Returns: `(torch.Tensor)`
            shape: (bs, response_length)
    """
    response_length = token_level_rewards.shape[-1]
    scores = token_level_rewards.sum(dim=-1)

    with torch.no_grad():
        returns = (token_level_rewards * eos_mask).flip(dims=[-1]).cumsum(dim=-1).flip(dims=[-1])
        advantages = returns - reward_baselines.unsqueeze(-1).tile([1, response_length]) * eos_mask

    return advantages, returns


def compute_rewards(token_level_scores, old_log_prob, ref_log_prob, kl_ratio):
    kl = old_log_prob - ref_log_prob
    return token_level_scores - kl * kl_ratio


# def compute_policy_loss(old_log_prob,
#                         log_prob,
#                         advantages,
#                         eos_mask,
#                         cliprange=None,
#                         cliprange_low=None,
#                         cliprange_high=None,
#                         use_token_level_loss=False):
#     """Adapted from https://github.com/huggingface/trl/blob/main/trl/trainer/ppo_trainer.py#L1122
#     Args:
#         old_log_prob: `(torch.Tensor)`
#             shape: (bs, response_length)
#         log_prob: `(torch.Tensor)`
#             shape: (bs, response_length)
#         advantages: `(torch.Tensor)`
#             shape: (bs, response_length)
#         eos_mask: `(torch.Tensor)`
#             shape: (bs, response_length)
#         cliprange: (float)
#             The clip range used in PPO. See https://arxiv.org/abs/1707.06347
#         cliprange_low: (float)
#             The lower clip range used in PPO.
#         cliprange_high: (float)
#             The higher clip range used in PPO.
#         use_token_level_loss: (bool)
#             Whether to use token level loss
#     Returns:
#         pg_loss: `a scalar torch.Tensor`
#             policy gradient loss computed via PPO
#         pg_clipfrac: (float)
#             the fraction of policy gradient loss being clipped
#         ppo_kl: (float)
#             the estimated KL divergence between the latest updating policy and the old sampling policy
#     """
#     seq_len_per_sample = torch.clamp(torch.sum(eos_mask, dim=1), min=1.0)
#     negative_approx_kl = log_prob - old_log_prob
#     ratio = torch.exp(negative_approx_kl)
#     ppo_kl = verl_F.masked_mean(-negative_approx_kl, eos_mask)

#     pg_losses1 = -advantages * ratio
#     if cliprange_low is None:
#         cliprange_low = cliprange
#     if cliprange_high is None:
#         cliprange_high = cliprange
#     pg_losses2 = -advantages * torch.clamp(ratio, 1 - cliprange_low,
#                                            1 + cliprange_high)  # - clip(ratio, 1-cliprange, 1+cliprange) * A
#     pg_losses = torch.maximum(pg_losses1, pg_losses2)  # max(-ratio * A, -clip(ratio, 1-cliprange, 1+cliprange) * A)

#     if use_token_level_loss:
#         pg_loss = verl_F.masked_mean(pg_losses, eos_mask)
#     else:
#         pg_loss = torch.sum(pg_losses * eos_mask, dim=1) / seq_len_per_sample
#         pg_loss = torch.mean(pg_loss)

#     pg_clipfrac = verl_F.masked_mean(torch.gt(pg_losses2, pg_losses1).float(), eos_mask)
#     return pg_loss, pg_clipfrac, ppo_kl

def compute_policy_loss(old_log_prob,
                        log_prob,
                        advantages,
                        eos_mask,
                        cliprange=None,
                        cliprange_low=None,
                        cliprange_high=None,
                        use_token_level_loss=False
                        ):
    """Adapted from https://github.com/huggingface/trl/blob/main/trl/trainer/ppo_trainer.py#L1122
    Args:
        old_log_prob: `(torch.Tensor)`
            shape: (bs, response_length)
        log_prob: `(torch.Tensor)`
            shape: (bs, response_length)
        advantages: `(torch.Tensor)`
            shape: (bs, response_length)
        eos_mask: `(torch.Tensor)`
            shape: (bs, response_length)
        cliprange: (float)
            The clip range used in PPO. See https://arxiv.org/abs/1707.06347
        cliprange_low: (float)
            The lower clip range used in PPO.
        cliprange_high: (float)
            The higher clip range used in PPO.
        use_token_level_loss: (bool)
            Whether to use token level loss
        sample_group_var: `(torch.Tensor)`
            形状：(bs, response_length)，每个 token 对应的样本组方差（已屏蔽 padding）
    Returns:
        pg_loss: `a scalar torch.Tensor`
            policy gradient loss computed via PPO
        pg_clipfrac: (float)
            the fraction of policy gradient loss being clipped
        ppo_kl: (float)
            the estimated KL divergence between the latest updating policy and the old sampling policy
    """

    """Adapted from https://github.com/huggingface/trl/blob/main/trl/trainer/ppo_trainer.py#L1122
    与源代码完全对齐：
    - 复用 verl_F.masked_mean（已有导入）
    - 适配传入的 token 级 rewards1_expanded/sample_group_var_expanded
    - 仅使用 PyTorch 内置操作和源代码变量
    """
    seq_len_per_sample = torch.clamp(torch.sum(eos_mask, dim=1), min=1.0)
    negative_approx_kl = log_prob - old_log_prob
    ratio = torch.exp(negative_approx_kl)
    ppo_kl = verl_F.masked_mean(-negative_approx_kl, eos_mask)

    pg_losses1 = -advantages * ratio
    if cliprange_low is None:
        cliprange_low = cliprange
    if cliprange_high is None:
        cliprange_high = cliprange
    pg_losses2 = -advantages * torch.clamp(ratio, 1 - cliprange_low,
                                           1 + cliprange_high)  # - clip(ratio, 1-cliprange, 1+cliprange) * A
    pg_losses = torch.maximum(pg_losses1, pg_losses2)  # max(-ratio * A, -clip(ratio, 1-cliprange, 1+cliprange) * A)

    if use_token_level_loss:
        pg_loss = verl_F.masked_mean(pg_losses, eos_mask)
    else:
        pg_loss = torch.sum(pg_losses * eos_mask, dim=1) / seq_len_per_sample
        pg_loss = torch.mean(pg_loss)

    pg_clipfrac = verl_F.masked_mean(torch.gt(pg_losses2, pg_losses1).float(), eos_mask)
    return pg_loss, pg_clipfrac, ppo_kl


def compute_entropy_loss(logits, eos_mask):
    """Compute Categorical entropy loss

    Args:
        logits: `(torch.Tensor)`
            shape: (bs, response_length, vocab_size)
        eos_mask: `(torch.Tensor)`
            shape: (bs, response_length)

    Returns:
        entropy: a scalar torch.Tensor

    """
    # compute entropy
    entropy = verl_F.entropy_from_logits(logits)  # (bs, response_len)
    entropy_loss = verl_F.masked_mean(entropy, mask=eos_mask)
    return entropy_loss


def compute_value_loss(vpreds, returns, values, eos_mask, cliprange_value):
    """Compute the value loss. Copied from https://github.com/huggingface/trl/blob/main/trl/trainer/ppo_trainer.py#L1151

    Args:
        vpreds (`torch.FloatTensor`):
            Predicted values of the value head, shape (`batch_size`, `response_length`)
        values (`torch.FloatTensor`):
            Old values of value head, shape (`batch_size`, `response_length`)
        returns: (`torch.FloatTensor`):
            Ground truth returns, shape (`batch_size`, `response_length`)

    Returns:
        vf_loss: a scalar (`torch.FloatTensor`):
            value function loss
        vf_clipfrac: a float
            The ratio of vf being clipped

    """
    vpredclipped = verl_F.clip_by_value(vpreds, values - cliprange_value, values + cliprange_value)
    vf_losses1 = (vpreds - returns)**2
    vf_losses2 = (vpredclipped - returns)**2
    vf_loss = 0.5 * verl_F.masked_mean(torch.max(vf_losses1, vf_losses2), eos_mask)
    vf_clipfrac = verl_F.masked_mean(torch.gt(vf_losses2, vf_losses1).float(), eos_mask)
    return vf_loss, vf_clipfrac


def kl_penalty(logprob: torch.FloatTensor, ref_logprob: torch.FloatTensor, kl_penalty) -> torch.FloatTensor:
    """Compute KL divergence given logprob and ref_logprob.
    Copied from https://github.com/huggingface/trl/blob/main/trl/trainer/ppo_trainer.py#L1104

    Args:
        logprob:
        ref_logprob:

    Returns:

    """
    if kl_penalty == "kl":
        return logprob - ref_logprob

    if kl_penalty == "abs":
        return (logprob - ref_logprob).abs()

    if kl_penalty == "mse":
        return 0.5 * (logprob - ref_logprob).square()

    # J. Schulman. Approximating kl divergence, 2020.
    # # URL http://joschu.net/blog/kl-approx.html.
    if kl_penalty == 'low_var_kl':
        kl = ref_logprob - logprob
        ratio = torch.exp(kl)
        kld = (ratio - kl - 1).contiguous()
        return torch.clamp(kld, min=-10, max=10)

    if kl_penalty == "full":
        # so, here logprob and ref_logprob should contain the logits for every token in vocabulary
        raise NotImplementedError

    raise NotImplementedError
