import re
import signal
from typing import Optional
# 新增LaTeX语义解析工具
from math_verify import parse as latex_parse, verify as latex_verify


def last_boxed_only_string(string: str) -> Optional[str]:
    """保持原有功能：提取最后一个\\boxed{}内容"""
    idx = string.rfind("\\boxed{")
    if idx < 0:
        return None

    i = idx
    right_brace_idx = None
    num_left_braces_open = 0

    while i < len(string):
        if string[i] == "{":
            num_left_braces_open += 1
        if string[i] == "}":
            num_left_braces_open -= 1
            if num_left_braces_open == 0:
                right_brace_idx = i
                break
        i += 1

    return string[idx:right_brace_idx + 1] if right_brace_idx is not None else None


def remove_boxed(s: str) -> str:
    """保持原有功能：移除\\boxed{}包装"""
    left = "\\boxed{"
    assert s[:len(left)] == left, f"box error: {s}"
    assert s[-1] == "}", f"box error: {s}"
    return s[len(left):-1]


class timeout:
    """保持原有超时处理功能"""
    def __init__(self, seconds=1, error_message="Timeout"):
        self.seconds = seconds
        self.error_message = error_message

    def handle_timeout(self, signum, frame):
        raise TimeoutError(self.error_message)

    def __enter__(self):
        signal.signal(signal.SIGALRM, self.handle_timeout)
        signal.alarm(self.seconds)

    def __exit__(self, type, value, traceback):
        signal.alarm(0)


# 保持原有规范化常量
SUBSTITUTIONS = [
    ("an ", ""), ("a ", ""), (".$", "$"), ("\\$", ""),
    (r"\ ", ""), (" ", ""), ("mbox", "text"),
    (",\\text{and}", ","), ("\\text{and}", ","), ("\\text{m}", "\\text{}"),
]

REMOVED_EXPRESSIONS = [
    "square", "ways", "integers", "dollars", "mph", "inches", "hours", "km",
    "units", "\\ldots", "sue", "points", "feet", "minutes", "digits", "cents",
    "degrees", "cm", "gm", "pounds", "meters", "meals", "edges", "students",
    "childrentickets", "multiples", "\\text{s}", "\\text{.}", "\\text{\ns}",
    "\\text{}^2", "\\text{}^3", "\\text{\n}", "\\text{}", r"\mathrm{th}",
    r"^\circ", r"^{\circ}", r"\;", r",\!", "{,}", '"', "\\dots",
]


def normalize_final_answer(final_answer: str) -> str:
    """增强版：在原有规范化基础上保留LaTeX结构"""
    final_answer = final_answer.split("=")[-1]

    # 保留原有字符串替换逻辑
    for before, after in SUBSTITUTIONS:
        final_answer = final_answer.replace(before, after)
    for expr in REMOVED_EXPRESSIONS:
        final_answer = final_answer.replace(expr, "")

    # 增强LaTeX处理：保留公式结构，仅移除冗余格式
    final_answer = re.sub(r"(.*?)(\$)(.*?)(\$)(.*)", "$\\3$", final_answer)
    final_answer = re.sub(r"(\\text\{)(.*?)(\})", "\\2", final_answer)  # 移除\text{}但保留内容
    final_answer = re.sub(r"(\\textbf\{)(.*?)(\})", "\\2", final_answer)
    final_answer = re.sub(r"(\\overline\{)(.*?)(\})", "\\2", final_answer)
    final_answer = re.sub(r"(\\boxed\{)(.*)(\})", "\\2", final_answer)

    # 补全LaTeX命令（支持\frac和sqrt的简写形式）
    final_answer = re.sub(r"(frac)([^{])(.)", "frac{\\2}{\\3}", final_answer)
    final_answer = re.sub(r"(sqrt)([^{])", "sqrt{\\2}", final_answer)
    final_answer = final_answer.replace("$", "")  # 移除$符号但保留公式结构

    # 数字规范化
    if final_answer.replace(",", "").isdigit():
        final_answer = final_answer.replace(",", "")

    return final_answer.strip()


def is_correct_minerva(solution_str: str,
                       gt: str,
                       gt_need_extract: bool = False,
                       answer_pattern: str = r"(?i)Answer\s*:\s*([^\n]+)") -> tuple[bool, str]:
    """增强版：加入LaTeX语义匹配"""
    # 提取模型答案（保留原有逻辑）
    match = re.findall(answer_pattern, solution_str)
    extracted_answer = match[-1] if match else "[INVALID]"
    pred = normalize_final_answer(extracted_answer)

    # 处理标准答案（保留原有逻辑）
    if gt_need_extract:
        gt = normalize_final_answer(remove_boxed(last_boxed_only_string(gt)))
    else:
        gt = normalize_final_answer(gt)

    # 新增：LaTeX语义解析与等价性判断
    try:
        # 解析为结构化数学对象
        parsed_pred = latex_parse(pred)
        parsed_gt = latex_parse(gt)
        # 非严格模式：忽略格式差异，匹配语义
        return latex_verify(parsed_pred, parsed_gt, strict=False), pred
    except:
        # 解析失败时降级为字符串匹配（兼容原有逻辑）
        return (pred == gt), pred


def is_correct_strict_box(pred: str,
                          gt: str,
                          pause_tokens_index: Optional[list[int]] = None) -> tuple[int, Optional[str]]:
    """保持原有严格模式逻辑：仅匹配boxed内容"""
    if pause_tokens_index is not None:
        assert len(pause_tokens_index) == 4
        pred = pred[pause_tokens_index[-1] - 100:]
    else:
        pred = pred[-100:]

    boxed_pred = last_boxed_only_string(pred)
    extracted_pred = remove_boxed(boxed_pred) if boxed_pred is not None else None

    # 严格模式下也对提取的内容进行LaTeX语义匹配
    if extracted_pred and gt:
        try:
            parsed_pred = latex_parse(extracted_pred)
            parsed_gt = latex_parse(gt)
            if latex_verify(parsed_pred, parsed_gt, strict=True):
                return 1, extracted_pred
        except:
            pass  # 解析失败时用原始字符串匹配

    return 1 if (extracted_pred == gt) else -1, extracted_pred


def verify(solution_str: str,
           answer: str,
           strict_box_verify: bool = False,
           pause_tokens_index: Optional[list[int]] = None) -> bool:
    """保持原有接口，内部使用增强版判断逻辑"""
    if strict_box_verify:
        correct, pred = is_correct_strict_box(solution_str, answer, pause_tokens_index)
        return correct == 1, pred

    correct, pred = is_correct_minerva(solution_str, answer)
    return correct, pred


def compute_score(solution_str: str,
                  ground_truth: str,
                  strict_box_verify: bool = False,
                  pause_tokens_index: Optional[list[int]] = None) -> float:
    """与原函数接口完全一致，返回值格式不变"""
    # 保留原有长度限制
    solution_str = solution_str[-300:]

    # 使用增强版验证逻辑
    correct, pred = verify(solution_str, ground_truth, strict_box_verify, pause_tokens_index)

    # 保持原有返回值结构
    return {
        "score": 1.0 if correct else -1.0,
        "acc": correct,
        "pred": pred,
    }
