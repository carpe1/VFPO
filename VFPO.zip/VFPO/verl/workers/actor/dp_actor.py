# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Single Process Actor
"""

import itertools
from typing import Iterable, Tuple

import torch
from torch import nn
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP

from verl import DataProto
from verl.trainer.ppo import core_algos
from verl.workers.actor import BasePPOActor
from verl.utils.py_functional import append_to_dict
from verl.utils.torch_functional import logprobs_from_logits, masked_mean
from verl.utils.ulysses import ulysses_pad_and_slice_inputs, gather_outpus_and_unpad
from verl.utils.seqlen_balancing import rearrange_micro_batches, get_reverse_idx
import verl.utils.torch_functional as verl_F

from flash_attn.bert_padding import pad_input, unpad_input, rearrange, index_first_axis

__all__ = ['DataParallelPPOActor']


class DataParallelPPOActor(BasePPOActor):

    def __init__(
        self,
        config,
        actor_module: nn.Module,
        actor_optimizer: torch.optim.Optimizer = None,
    ):
        """When optimizer is None, it is Reference Policy"""
        super().__init__(config)
        self.actor_module = actor_module
        self.actor_optimizer = actor_optimizer
        self.use_remove_padding = self.config.get('use_remove_padding', False)
        print(f'Actor use_remove_padding={self.use_remove_padding}')
        self.ulysses_sequence_parallel_size = self.config.ulysses_sequence_parallel_size
        self.use_ulysses_sp = self.ulysses_sequence_parallel_size > 1

        self.compute_entropy_from_logits = (
            torch.compile(verl_F.entropy_from_logits, dynamic=True)
            if self.config.get('use_torch_compile', True)  #  use torch compile by default
            else verl_F.entropy_from_logits)

    # ========== 修复1：添加self参数，改为实例方法 ==========
    def mask_high_entropy_tokens(self, entropy: torch.Tensor, response_mask: torch.Tensor, top_percent: float = 0.8):
        """
        筛选每个样本前N%的高熵Token，生成掩码
        Args:
            entropy: 熵张量，shape=[bsz, response_len]
            response_mask: 响应Token掩码（有效Token为1），shape=[bsz, response_len]
            top_percent: 保留的高熵Token比例（如0.8表示保留前80%）
        Returns:
            masked_entropy: 仅保留高熵Token的熵值（其余置0），shape=[bsz, response_len]
            high_ent_mask: 高熵Token掩码（1=保留，0=过滤），shape=[bsz, response_len]
            quantile_bound: 分位数下界（用于监控），shape=[bsz, 1]
        """
        # 用NaN填充padding位置（避免分位数计算受padding影响）
        entropy_masked = entropy.masked_fill(~response_mask.bool(), float('nan')).float()
        # 计算分位数下界（前80%高熵 → 下界为20%分位数）
        lower_quantile = 1.0 - top_percent  # 0.2
        quantile_bound = torch.nanquantile(entropy_masked, lower_quantile, dim=-1, keepdim=True)
        # 生成高熵Token掩码（熵≥下界的Token保留）

        # 新增：打印关键统计（修复梯度张量转numpy的问题）
        print(f"\n【高熵掩码生成】")
        print(f"top_percent={top_percent}, lower_quantile={lower_quantile}")
        # 熵值的均值/最小/最大值用.item()是安全的（无需detach）
        print(f"熵值统计：均值={entropy.mean().item():.6f}, 最小值={entropy.min().item():.6f}, 最大值={entropy.max().item():.6f}")
        # 关键修复：先detach()脱离计算图，再转cpu和numpy
        quantile_bound_print = quantile_bound[:10].squeeze(-1).detach().cpu().numpy()
        print(f"前10个样本的分位数下界：{quantile_bound_print}")
        # 计算生成时的高熵占比（同样确保张量脱离计算图）
        high_ent_bool = (entropy >= quantile_bound).detach()
        high_ent_count = high_ent_bool.sum().item()
        response_mask_count = response_mask.sum().item()
        high_ent_ratio = high_ent_count / response_mask_count if response_mask_count > 0 else 0.0
        print(f"生成时熵≥下界的占比：{high_ent_ratio:.4f}")


        high_ent_mask = (entropy >= quantile_bound) & response_mask.bool()  # 结合有效Token掩码
        # 仅保留高熵Token的熵值
        masked_entropy = torch.where(high_ent_mask, entropy, torch.zeros_like(entropy))
        return masked_entropy, high_ent_mask, quantile_bound

    def compute_e_pi_new(self, logits, top_p, top_k, temperature=1.0):
        """计算top-p掩码内的概率平方和（e_pi_new = sum(pi_new^2)）"""
        # 【新增】打印输入logits的原始形状和sp_size，定位维度来源
        # 1. 打印输入形状，方便调试追踪
        # print(f"compute_e_pi_new 输入: logits形状={logits.shape}, 维度数={logits.dim()}")
        top_p=0.95
        top_k=100

        # 2. 维度处理：仅允许s三维（已合并）或四维（需合并）
        if logits.dim() == 4:
            # 四维情况：(batch_size, seq_len, sp_size, vocab_per_sp) → 合并后两维
            batch_size, seq_len, sp_size, vocab_per_sp = logits.shape
            # 合并 sp_size 和 vocab_per_sp 为总词表维度（sp_size * vocab_per_sp）
            logits = logits.reshape(batch_size, seq_len, -1)  # -1 自动计算总词表大小
            # print(f"合并序列并行维度: sp_size={sp_size}, vocab_per_sp={vocab_per_sp} → 总vocab={logits.shape[2]}")
            # print(f"合并后 logits 形状: {logits.shape}")
        elif logits.dim() == 3:
            # 三维情况：直接使用（已合并完成）
            print(f"logits 已为三维，无需合并: {logits.shape}")
        else:
            # 其他维度：报错并提示预期形状
            raise ValueError(
                f"logits 仅支持 3 维（已合并）或 4 维（需合并），实际维度数={logits.dim()}, 形状={logits.shape}。"
                f"预期形状示例：\n"
                f"- 四维（需合并）: (batch_size, seq_len, sp_size, vocab_per_sp)\n"
                f"- 三维（已合并）: (batch_size, seq_len, vocab_total)"
            )

        # print(f"当前掩码参数: top_p={top_p}, top_k={top_k}, temperature={temperature}")
        batch_size, seq_len, vocab_size = logits.shape
        top_k = min(top_k, vocab_size) 
        device = logits.device

        # 应用温度系数（与log_probs计算保持一致）
        logits = logits / temperature # 形状：(batch_size, seq_len, top_k) 已提前截断

        # 1. 批量获取每个位置的top-k logits和概率（向量化替代第一层循环）        # 1. 直接计算top_k概率（无需再调用torch.topk，已提前截断）
        # topk_logits: [batch_size, seq_len, top_k]，topk_indices: [batch_size, seq_len, top_k]
        # topk_logits, topk_indices = torch.topk(logits, k=top_k, dim=2)
        topk_probs = torch.softmax(logits, dim=2)  # 对top-k logits归一化：[batch_size, seq_len, top_k]

        # 2. 批量找到每个位置第一个小于0.01的概率位置（向量化替代第二层循环）
        mask_less_001 = topk_probs < 0.01  # 掩码：[batch_size, seq_len, top_k]，True表示小于0.01
        # 找到每个(batch, seq)中第一个True的索引（argmax返回第一个1的位置）
        first_less_001_pos = torch.argmax(mask_less_001.float(), dim=2)  # 形状：[batch_size, seq_len]
        # 若该位置全为False（无小于0.01的概率），则设为top_k
        has_less = mask_less_001.any(dim=2)  # 形状：[batch_size, seq_len]，标记是否存在小于0.01的概率
        first_less_001_pos = torch.where(has_less, first_less_001_pos, top_k)  # 补全无符合条件的情况

        # 3. 批量计算top-p截断点（修复searchsorted参数问题）
        cumulative_probs = torch.cumsum(topk_probs, dim=2)  # 形状：[batch_size, seq_len, top_k]
        # 关键修复：
        # 1. 将top_p转换为张量并扩展维度，匹配cumulative_probs的批量维度（[batch_size, seq_len, 1]）
        top_p_tensor = torch.tensor([top_p], device=cumulative_probs.device).expand(
            cumulative_probs.shape[0], cumulative_probs.shape[1], 1  # 扩展为[bs, seq_len, 1]
        )
        # 2. 调用searchsorted：移除dim参数（旧版不支持），默认对最后一维（top_k维）搜索
        cutoff_idx = torch.searchsorted(cumulative_probs, top_p_tensor, right=True)  # 形状：[batch_size, seq_len, 1]
        # 3. 压缩最后一维，得到[batch_size, seq_len]（与原逻辑一致）
        cutoff_idx = cutoff_idx.squeeze(-1)
        cutoff_idx = torch.clamp(cutoff_idx, min=1)  # 确保至少保留1个token

        # 4. 批量计算e_pi_new（top-p内概率的平方和）
        # 生成top-p掩码：每个位置前cutoff_idx个元素为True
        top_p_mask = torch.arange(top_k, device=device).unsqueeze(0).unsqueeze(0) < cutoff_idx.unsqueeze(-1)
        # 应用掩码并计算平方和
        top_p_probs_masked = topk_probs * top_p_mask.float()  # 仅保留top-p内的概率
        e_pi_new = torch.sum(top_p_probs_masked** 2, dim=2)  # 平方和：[batch_size, seq_len]

        # 保留原打印逻辑（验证特定位置）
        # if batch_size > 8 and seq_len > 0:
        #     print(f"样本8-序列0（token位置）: top_p截断后保留={cutoff_idx[8,0].item()}个token, "
        #         f"top_k概率中第一个小于0.01的位置为 {first_less_001_pos[8,0].item()}")

        # 【显存优化3：主动释放无用中间变量，强制回收显存】
        del logits, topk_probs, mask_less_001, cumulative_probs, top_p_tensor, top_p_mask, top_p_probs_masked
    
        return e_pi_new
        # 【新增结束】

    def _forward_micro_batch(self, micro_batch, temperature) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns: 
            entropy: # (bs, response_len)
            log_probs: # (bs, response_len)
        """
        response_length = micro_batch['responses'].size(-1)
        multi_modal_inputs = {}
        if 'multi_modal_inputs' in micro_batch:
            for key in micro_batch['multi_modal_inputs'][0].keys():
                multi_modal_inputs[key] = torch.cat([inputs[key] for inputs in micro_batch['multi_modal_inputs']],
                                                    dim=0)

        # 【新增】从meta_info获取top_p/top_k（核心：参数来源）
        # meta_info = micro_batch.get('meta_info', {})  # 从micro_batch取meta_info
        meta_info = getattr(micro_batch, 'meta_info', {})  # 从DataProto属性获取meta_info
        top_p = meta_info.get('top_p',0.95)
        top_k = meta_info.get('top_k',100)
        # 打印参数及来源
        print(f"dp_actor 接收参数：top_p={top_p}, top_k={top_k}")
        with torch.autocast(device_type='cuda', dtype=torch.bfloat16):
            input_ids = micro_batch['input_ids']
            batch_size, seqlen = input_ids.shape
            attention_mask = micro_batch['attention_mask']
            position_ids = micro_batch['position_ids']
            if position_ids.dim() == 3:  # qwen2vl mrope
                position_ids = position_ids.transpose(0, 1)  # (bsz, 3, seqlen) -> (3, bsz, seqlen)

            if self.use_remove_padding:
                input_ids_rmpad, indices, *_ = unpad_input(input_ids.unsqueeze(-1),
                                                           attention_mask)  # input_ids_rmpad (total_nnz, ...)
                input_ids_rmpad = input_ids_rmpad.transpose(0, 1)  # (1, total_nnz)

                # unpad the position_ids to align the rotary
                if position_ids.dim() == 3:
                    position_ids_rmpad = index_first_axis(rearrange(position_ids, "c b s ... -> (b s) c ..."),
                                                          indices).transpose(0, 1).unsqueeze(
                                                              1)  # (3, bsz, seqlen) -> (3, 1, bsz * seqlen)
                else:
                    position_ids_rmpad = index_first_axis(rearrange(position_ids.unsqueeze(-1), "b s ... -> (b s) ..."),
                                                          indices).transpose(0, 1)

                # for compute the log_prob
                input_ids_rmpad_rolled = torch.roll(input_ids_rmpad, shifts=-1, dims=1)  # (1, total_nnz)

                # pad and slice the inputs if sp > 1
                if self.use_ulysses_sp:
                    input_ids_rmpad, position_ids_rmpad, pad_size = ulysses_pad_and_slice_inputs(input_ids_rmpad, \
                                                                                                position_ids_rmpad, \
                                                                                                sp_size=self.ulysses_sequence_parallel_size)
                    input_ids_rmpad_rolled, _, _ = ulysses_pad_and_slice_inputs(input_ids_rmpad_rolled, None,
                                                                                self.ulysses_sequence_parallel_size)

                input_ids_rmpad_rolled = input_ids_rmpad_rolled.squeeze(0)  # ((total_nnz / sp) + pad)

                # only pass input_ids and position_ids to enable flash_attn_varlen
                output = self.actor_module(input_ids=input_ids_rmpad,
                                           attention_mask=None,
                                           position_ids=position_ids_rmpad,
                                           **multi_modal_inputs,
                                           use_cache=False)  # prevent model thinks we are generating
                logits_rmpad = output.logits.squeeze(0)  # (total_nnz, vocab_size)

                logits_rmpad.div_(temperature)

                # compute entropy
                entropy_rmpad = self.compute_entropy_from_logits(logits_rmpad)  # ((total_nnz / sp) + pad)

                # if use_sp: ((total_nnz / sp) + pad) ; if not use_sp: (batch, seqlen)
                log_probs = logprobs_from_logits(logits=logits_rmpad, labels=input_ids_rmpad_rolled)

                # gather log_prob if sp > 1
                if self.use_ulysses_sp:
                    # gather and unpad for the ulysses sp
                    log_probs = gather_outpus_and_unpad(log_probs, gather_dim=0, unpad_dim=0, padding_size=pad_size)
                    entropy_rmpad = gather_outpus_and_unpad(entropy_rmpad,
                                                            gather_dim=0,
                                                            unpad_dim=0,
                                                            padding_size=pad_size)
                    # 【新增：gather logits_rmpad用于后续计算e_pi_new】
                    logits_rmpad = gather_outpus_and_unpad(logits_rmpad, gather_dim=0, unpad_dim=0, padding_size=pad_size)
                # pad back to (bsz, seqlen)
                full_entropy = pad_input(hidden_states=entropy_rmpad.unsqueeze(-1),
                                         indices=indices,
                                         batch=batch_size,
                                         seqlen=seqlen)
                full_log_probs = pad_input(hidden_states=log_probs.unsqueeze(-1),
                                           indices=indices,
                                           batch=batch_size,
                                           seqlen=seqlen)

                # # 【核心修改3：pad回完整logits，用于截取response部分】
                # topk_logits_rmpad, _ = torch.topk(logits_rmpad, k=top_k, dim=1)  # (total_nnz, top_k) 1. 对未pad的logits_rmpad先做topk（体积小，无padding）
                # full_logits = pad_input(hidden_states=topk_logits_rmpad.unsqueeze(-1),  # 将unpad的logits恢复为完整序列
                #                         indices=indices,
                #                         batch=batch_size,
                #                         seqlen=seqlen).squeeze(-1)  # 形状：(bsz, seqlen, vocab_size)
                # # 截取response部分logits：仅用response序列计算e_pi_new
                # topk_logits = full_logits[:, -response_length - 1:-1, :]  # 形状：(bsz, response_len, vocab_size)

                # # 【显存优化5：释放完整词表的logits，立即回收大量显存】
                # del topk_logits_rmpad, full_logits, logits_rmpad  # 这些变量后续不再使用，直接删除
                # # 【核心修改4：调用compute_e_pi_new，传入response_logits和meta_info的参数】
                # e_pi_new = self.compute_e_pi_new(
                #     logits=topk_logits,  # 仅用response部分logits
                #     top_p=top_p,             # 从meta_info获取
                #     top_k=top_k,             # 从meta_info获取
                #     temperature=temperature
                # )

                # only return response part:
                entropy = full_entropy.squeeze(-1)[:, -response_length - 1:-1]  # (bsz, response_length)
                log_probs = full_log_probs.squeeze(-1)[:, -response_length - 1:-1]  # (bsz, response_length)

            else:  # not using rmpad and no ulysses sp
                output = self.actor_module(input_ids=input_ids,
                                           attention_mask=attention_mask,
                                           position_ids=position_ids,
                                           **multi_modal_inputs,
                                           use_cache=False)  # prevent model thinks we are generating
                logits = output.logits
                logits.div_(temperature)
                response_logits = logits[:, -response_length - 1:-1, :]  # (bsz, response_length, vocab_size)
                log_probs = logprobs_from_logits(response_logits, micro_batch['responses'])  # 复用response_logits
                entropy = verl_F.entropy_from_logits(response_logits)  # 复用response_logits
                
                # # 【显存优化4：同样提前截断为top_k维度】
                # topk_logits, _ = torch.topk(response_logits, k=top_k, dim=2)
                
                # # 【显存优化5：释放完整logits】
                # del response_logits, logits

                # e_pi_new = self.compute_e_pi_new(
                #     logits=topk_logits,  # 仅用response部分logits
                #     top_p=top_p,             # 从meta_info获取
                #     top_k=top_k,             # 从meta_info获取
                #     temperature=temperature
                # )

            # ========== 修复2：调用方法时添加self.前缀 ==========
            # entropy是response部分的熵，shape=[bsz, response_len]
            # response_mask = attention_mask[:, -response_length:]  # [bsz, response_len]
            response_mask = attention_mask[:, -response_length - 1:-1] # 和entropy切片一致
            # 筛选前80%高熵Token
            _, high_ent_mask_low , _ = self.mask_high_entropy_tokens(entropy, response_mask, top_percent=0.1)
            _, high_ent_mask_high , _ = self.mask_high_entropy_tokens(entropy, response_mask, top_percent=0.8)
            # ===========================================

            return entropy, log_probs, high_ent_mask_low ,high_ent_mask_high

    def _optimizer_step(self):
        assert self.config.grad_clip is not None

        if isinstance(self.actor_module, FSDP):
            grad_norm = self.actor_module.clip_grad_norm_(max_norm=self.config.grad_clip)
        else:
            grad_norm = torch.nn.utils.clip_grad_norm_(self.actor_module.parameters(), max_norm=self.config.grad_clip)
        self.actor_optimizer.step()
        return grad_norm

    def compute_log_prob(self, data: DataProto) -> DataProto:
        """Compute the log probability of the responses given input_ids, attention_mask and position_ids

        Args:
            data (DataProto): a DataProto containing keys

                ``input_ids``: tensor of shape [batch_size, sequence_length]. torch.int64. Note that input_ids is the
                concatenation of prompt and response. Note that ``sequence_length = prompt_length + response_length``.

                ``attention_mask``: tensor of shape [batch_size, sequence_length]. torch.int64.

                ``position_ids``: tensor of shape [batch_size, sequence_length]. torch.int64.

                ``responses``:  tensor of shape [batch_size, response_length]. torch.int64.

        Returns:
            torch.Tensor: the log_prob tensor
        """
        # set to eval
        self.actor_module.eval()

        micro_batch_size = data.meta_info['micro_batch_size']
        temperature = data.meta_info['temperature']  # temperature must be in the data.meta_info to avoid slient error
        use_dynamic_bsz = data.meta_info['use_dynamic_bsz']

        select_keys = ['responses', 'input_ids', 'attention_mask', 'position_ids']
        batch = data.select(batch_keys=select_keys).batch
        has_multi_modal_inputs = 'multi_modal_inputs' in data.non_tensor_batch.keys()

        if has_multi_modal_inputs:
            num_micro_batches = data.batch.batch_size[0] // micro_batch_size
            non_tensor_select_keys = ['multi_modal_inputs']
            micro_batches = data.select(select_keys, non_tensor_select_keys).chunk(num_micro_batches)
        elif use_dynamic_bsz:
            # split using dynamic bsz
            max_token_len = data.meta_info['max_token_len'] * self.ulysses_sequence_parallel_size
            micro_batches, indices = rearrange_micro_batches(batch=batch, max_token_len=max_token_len)
        else:
            micro_batches = batch.split(micro_batch_size)

        log_probs_lst = []
        high_ent_mask_low_lst = []  # 新增：存储每个微批次的高熵掩码
        high_ent_mask_high_lst = []  # 新增：存储每个微批次的高熵掩码
        for micro_batch in micro_batches:
            if isinstance(micro_batch, DataProto):
                micro_batch = {**micro_batch.batch, **micro_batch.non_tensor_batch}

            with torch.no_grad():
                _, log_probs, high_ent_mask_low, high_ent_mask_high= self._forward_micro_batch(micro_batch=micro_batch, temperature=temperature)
            log_probs_lst.append(log_probs)
            high_ent_mask_low_lst.append(high_ent_mask_low)  # 收集掩码
            high_ent_mask_high_lst.append(high_ent_mask_high)  # 收集掩码
        log_probs = torch.concat(log_probs_lst, dim=0)
        high_ent_mask_low = torch.concat(high_ent_mask_low_lst, dim=0)  # [总bsz, response_len]
        high_ent_mask_high = torch.concat(high_ent_mask_high_lst, dim=0)  # [总bsz, response_len]

        if use_dynamic_bsz:
            indices = list(itertools.chain.from_iterable(indices))
            assert len(indices) == log_probs.size(0), f"{len(indices)} vs. {log_probs.size()}"
            revert_indices = torch.tensor(get_reverse_idx(indices), dtype=torch.long)
            log_probs = log_probs[revert_indices]
            high_ent_mask_low = high_ent_mask_low[revert_indices]  # 恢复动态batch的原始顺序
            high_ent_mask_high = high_ent_mask_high[revert_indices]  # 恢复动态batch的原始顺序

        # # 新增打印
        # high_ent_ratio = high_ent_mask.sum().item() / response_mask.sum().item()
        # print(f"【掩码收集后】高熵Token占比：{high_ent_ratio:.4f}")

        # ========== 核心：仅写入掩码到data.batch，返回值必须是Tensor ==========
        from tensordict import TensorDict
        # 1. 初始化data.batch（避免None）
        if data.batch is None:
            data.batch = TensorDict({}, batch_size=log_probs.shape[:1])
        # 2. 写入字段（转CPU避免序列化问题）
        data.batch['old_log_probs'] = log_probs.cpu()
        data.batch['high_ent_token_mask_low'] = high_ent_mask_low.cpu()
        data.batch['high_ent_token_mask_high'] = high_ent_mask_high.cpu()
        # 3. 返回值必须是Tensor（fsdp_workers预期的类型）
        return log_probs  # 重点：返回Tensor，不是DataProto！

    def update_policy(self, data: DataProto):
        # make sure we are in training mode
        self.actor_module.train()

        temperature = data.meta_info['temperature']  # temperature must be in the data.meta_info to avoid slient error

        select_keys = ['responses', 'input_ids', 'attention_mask', 'position_ids', 'old_log_probs', 'advantages']
        # select_keys = ['responses', 'input_ids', 'attention_mask', 'position_ids', 'old_log_probs', 'advantages', 'rewards1','sample_group_var','group_index']
        if self.config.use_kl_loss:
            select_keys.append('ref_log_prob')
        batch = data.select(batch_keys=select_keys).batch
        has_multi_modal_inputs = 'multi_modal_inputs' in data.non_tensor_batch.keys()

        # Split to make minibatch iterator for updating the actor
        # See PPO paper for details. https://arxiv.org/abs/1707.06347
        if has_multi_modal_inputs:
            num_mini_batches = data.batch.batch_size[0] // self.config.ppo_mini_batch_size
            non_tensor_select_keys = ['multi_modal_inputs']
            dataloader = data.select(select_keys, non_tensor_select_keys).chunk(num_mini_batches)
        else:
            dataloader = batch.split(self.config.ppo_mini_batch_size)

        metrics = {}
        for epoch in range(self.config.ppo_epochs):
            for batch_idx, data in enumerate(dataloader):
                # split batch into micro_batches
                mini_batch = data
                if has_multi_modal_inputs:
                    self.gradient_accumulation = self.config.ppo_mini_batch_size // self.config.ppo_micro_batch_size_per_gpu
                    num_micro_batches = mini_batch.batch.batch_size[0] // self.config.ppo_micro_batch_size_per_gpu
                    micro_batches = data.select(select_keys, non_tensor_select_keys).chunk(num_micro_batches)
                elif self.config.use_dynamic_bsz:
                    max_token_len = self.config.ppo_max_token_len_per_gpu * self.ulysses_sequence_parallel_size
                    micro_batches, _ = rearrange_micro_batches(batch=mini_batch, max_token_len=max_token_len)
                else:
                    self.gradient_accumulation = self.config.ppo_mini_batch_size // self.config.ppo_micro_batch_size_per_gpu
                    # split batch into micro_batches
                    micro_batches = mini_batch.split(self.config.ppo_micro_batch_size_per_gpu)

                self.actor_optimizer.zero_grad()

                for data in micro_batches:
                    # Support all hardwares
                    if isinstance(data, DataProto):
                        data = {**data.batch.to(torch.cuda.current_device()), **data.non_tensor_batch}
                    else:
                        data = data.to(torch.cuda.current_device())  # actor device is cpu when using offload
                    responses = data['responses']
                    response_length = responses.size(1)
                    attention_mask = data['attention_mask']
                    response_mask = attention_mask[:, -response_length:]
                    old_log_prob = data['old_log_probs']
                    advantages = data['advantages']

                    # # 1. 提取rewards1（原始形状：(bs,)）
                    # rewards1 = data['rewards1']
                    # # 2. 扩展形状为(bs, response_length)，并通过response_mask屏蔽padding
                    # # unsqueeze(1)：(bs,) → (bs, 1)；乘response_mask：广播到(bs, response_length)并屏蔽padding
                    # rewards1_expanded = rewards1.unsqueeze(1) * response_mask  # 最终形状：(bs, response_length)

                    # # 2. 读取 sample_group_var（(bs,)），扩展到 token 级
                    # sample_group_var = data['sample_group_var']  # (bs,)
                    # group_index = data['group_index'] 
                    # # sample_group_var = sample_group_var.to(device)
                    # # 扩展为 (bs, response_length)，与 advantages、log_prob 维度对齐
                    # sample_group_var_expanded = sample_group_var.unsqueeze(1) * response_mask  # (bs, response_length)

                    clip_ratio = self.config.clip_ratio
                    clip_ratio_low = self.config.clip_ratio_low if self.config.clip_ratio_low is not None else clip_ratio
                    clip_ratio_high = self.config.clip_ratio_high if self.config.clip_ratio_high is not None else clip_ratio
                    entropy_coeff = self.config.entropy_coeff
                    use_token_level_loss = self.config.use_token_level_loss

                    # all return: (bsz, response_length)
                    # entropy, log_prob, e_pi_new = self._forward_micro_batch(micro_batch=data, temperature=temperature)
                    entropy, log_prob, high_ent_mask_low, high_ent_mask_high= self._forward_micro_batch(micro_batch=data, temperature=temperature)

                    pg_loss, pg_clipfrac, ppo_kl = core_algos.compute_policy_loss(
                        old_log_prob=old_log_prob,
                        log_prob=log_prob,
                        advantages=advantages,
                        eos_mask=response_mask,
                        cliprange=clip_ratio,
                        cliprange_low=clip_ratio_low,
                        cliprange_high=clip_ratio_high,
                        use_token_level_loss=use_token_level_loss
                        # rewards1=rewards1_expanded,
                        # sample_group_var=sample_group_var_expanded, # 新增：token 级组方差
                        # group_index=group_index,
                        # high_ent_mask=high_ent_mask_low  # 新增：传递高熵Token掩码
                    )
                    # compute entropy loss from entropy
                    entropy_loss = verl_F.masked_mean(entropy, response_mask)

                    # compute policy loss
                    policy_loss = pg_loss - entropy_loss * entropy_coeff

                    if self.config.use_kl_loss:
                        ref_log_prob = data['ref_log_prob']
                        # compute kl loss
                        kld = core_algos.kl_penalty(logprob=log_prob,
                                                    ref_logprob=ref_log_prob,
                                                    kl_penalty=self.config.kl_loss_type)
                        kl_loss = masked_mean(kld, response_mask)

                        policy_loss = policy_loss + kl_loss * self.config.kl_loss_coef
                        metrics['actor/kl_loss'] = kl_loss.detach().item()
                        metrics['actor/kl_coef'] = self.config.kl_loss_coef

                    if self.config.use_dynamic_bsz:
                        # relative to the dynamic bsz
                        loss = policy_loss * (len(data) / self.config.ppo_mini_batch_size)
                    else:
                        loss = policy_loss / self.gradient_accumulation
                    loss.backward()

                    data = {
                        'actor/entropy': entropy_loss.detach().item(),
                        'actor/pg_loss': pg_loss.detach().item(),
                        'actor/pg_clipfrac': pg_clipfrac.detach().item(),
                        'actor/ppo_kl': ppo_kl.detach().item()
                    }
                    append_to_dict(metrics, data)

                grad_norm = self._optimizer_step()
                data = {'actor/grad_norm': grad_norm.detach().item()}
            append_to_dict(metrics, data)
        self.actor_optimizer.zero_grad()
        return metrics
